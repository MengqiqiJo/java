package com;

public interface Sortable {
	boolean lessThan(Sortable anObject);

}
