package com;

public interface FeeCalculator {
	public double computeFees();

}
