package com;


import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class FinalUserFrame extends JFrame implements ActionListener{
	private JTextField inputArea;
	private JTextArea outputArea;
	
	private JLabel label1;
	
	private JButton unsortedStudents;
	private JButton descendingStudents;
	private JButton ascendingStudents;
	
	private University aUniversity;
	private OutputFrame frameToShowSortedListOfStudent;
	
	public FinalUserFrame(University someUniversity){
		super("input frame");
		setSize(500,500);
		aUniversity=someUniversity;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new FlowLayout());
		
		label1=new JLabel("enter name of country");
		add(label1);
		
		inputArea=new JTextField(20);
		add(inputArea);
		inputArea.addActionListener(this);
		
		outputArea=new JTextArea(25,45);
		add(outputArea);
		
		unsortedStudents=new JButton("show students");	
		unsortedStudents.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				outputArea.setText(aUniversity.toString());
			}	
		});
		add(unsortedStudents);
		
		ascendingStudents=new JButton("show students sorted ascending");	
		ascendingStudents.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				Student.setSortingFlag(false);
				aUniversity.sortStudents();
				frameToShowSortedListOfStudent=new OutputFrame("sorted list (ascending) of students");
				frameToShowSortedListOfStudent.displayMessage(aUniversity.toString());
			}
		});
		add(ascendingStudents);
		
		
		descendingStudents=new JButton("show students sorted descending");
		
		descendingStudents.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				Student.setSortingFlag(true);
				aUniversity.sortStudents();
				frameToShowSortedListOfStudent=new OutputFrame("sorted list (descendingStudents) of students");
				frameToShowSortedListOfStudent.displayMessage(aUniversity.toString());
			}
		});		
		add(descendingStudents);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent e){
		String nameOfCountry;
		String output;
		nameOfCountry=inputArea.getText();
		inputArea.setText("");
		output="Number of students from"+nameOfCountry+"is"+
		aUniversity.numberOfStudents(nameOfCountry);
		outputArea.setText(output);
	}
}

